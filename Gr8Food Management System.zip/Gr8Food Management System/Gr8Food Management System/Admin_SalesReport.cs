﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Admin_SalesReport : Form
    {
        public Admin_SalesReport()
        {
            InitializeComponent();
        }

        private void SalesReport_Load(object sender, EventArgs e)
        {
            LoadSalesReport();
        }

        void LoadSalesReport()
        {
            SqlConnection con = new SqlConnection(
"Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT 
                    o.OrderID,
                    o.CustomerID,
                    m.MenuName,
                    c.CategoryName,
                    u.Username AS Chef,
                    od.Quantity,
                    od.Price,
                    (od.Quantity * od.Price) AS TotalSale,
                    o.Status
                    FROM Orders o
                    JOIN OrderDetails od ON o.OrderID = od.OrderID
                    JOIN Menu m ON od.MenuID = m.MenuID
                    JOIN Categories c ON m.CategoryID = c.CategoryID
                    JOIN Users u ON m.ChefID = u.UserID";

                SqlDataAdapter da = new SqlDataAdapter(query, con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvSalesReport.DataSource = dt;
                dgvSalesReport.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AdminDashboard admin = new AdminDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
