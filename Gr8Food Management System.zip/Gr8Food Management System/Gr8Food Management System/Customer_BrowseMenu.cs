﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Customer_BrowseMenu : Form
    {
        public Customer_BrowseMenu()
        {
            InitializeComponent();
        }

        private void Customer_BrowseMenu_Load(object sender, EventArgs e)
        {
            LoadMenu();
        }

        void LoadMenu()
        {
            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT m.MenuID,
                                m.MenuName,
                                m.Description,
                                m.Price,
                                c.CategoryName
                         FROM Menu m
                         JOIN Categories c ON m.CategoryID = c.CategoryID
                         WHERE m.IsAvailable = 1";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvMenu.DataSource = dt;
                dgvMenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvMenu.ReadOnly = true;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CustomerDashboard admin = new CustomerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
