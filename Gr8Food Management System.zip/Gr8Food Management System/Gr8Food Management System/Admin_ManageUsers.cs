﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Admin_ManageUsers : Form
    {
        public Admin_ManageUsers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = "INSERT INTO Users (FullName, Email, Phone, Username, Password, Role) VALUES (@name,@email,@phone,@username,@password,@role)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@name", txtFullName.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@role", cmbRole.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("User Added Successfully");

                con.Close();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = "UPDATE Users SET Password=@password WHERE Username=@username";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@username", txtEditUsername.Text);
                cmd.Parameters.AddWithValue("@password", txtNewPassword.Text);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    MessageBox.Show("Password Updated Successfully");
                }
                else
                {
                    MessageBox.Show("User not found");
                }

                con.Close();
                ClearFields();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                int userID = Convert.ToInt32(txtUserID.Text);

                SqlCommand cmd = new SqlCommand();

                cmd.Connection = con;

                cmd.CommandText = @"
        DELETE FROM Feedback WHERE CustomerID=@id;

        DELETE FROM WalletTransactions WHERE UserID=@id;

        DELETE FROM Wallet WHERE UserID=@id;

        DELETE FROM Orders WHERE CustomerID=@id;

        DELETE FROM Menu WHERE ChefID=@id;

        DELETE FROM Users WHERE UserID=@id;
        ";

                cmd.Parameters.AddWithValue("@id", userID);

                cmd.ExecuteNonQuery();

                MessageBox.Show("User Deleted Successfully");

                con.Close();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ClearFields()
        {
            txtFullName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            cmbRole.SelectedIndex = -1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AdminDashboard admin = new AdminDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
