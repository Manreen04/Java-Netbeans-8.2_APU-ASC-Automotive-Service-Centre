﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Chef_View_UpdateOrders : Form
    {
        public Chef_View_UpdateOrders()
        {
            InitializeComponent();
        }

        private void Chef_View_UpdateOrders_Load(object sender, EventArgs e)
        {
            LoadOrders();
        }
        void LoadOrders()
        {
            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT o.OrderID,
                                o.CustomerID,
                                o.OrderDate,
                                o.TotalAmount,
                                o.Status
                         FROM Orders o
                         JOIN OrderDetails od ON o.OrderID = od.OrderID
                         JOIN Menu m ON od.MenuID = m.MenuID
                         WHERE m.ChefID = @chef
                         GROUP BY o.OrderID, o.CustomerID, o.OrderDate, o.TotalAmount, o.Status";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@chef", Session.UserID);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvOrders.DataSource = dt;
                dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvOrders.ReadOnly = true;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtOrderID.Text == "" || cmbStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Please enter Order ID and select status");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"UPDATE Orders
                         SET Status=@status
                         WHERE OrderID=@id";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@status", cmbStatus.Text);
                cmd.Parameters.AddWithValue("@id", txtOrderID.Text);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    MessageBox.Show("Order status updated successfully");
                    LoadOrders();
                }
                else
                {
                    MessageBox.Show("Order not found");
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChefDashboard admin = new ChefDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
