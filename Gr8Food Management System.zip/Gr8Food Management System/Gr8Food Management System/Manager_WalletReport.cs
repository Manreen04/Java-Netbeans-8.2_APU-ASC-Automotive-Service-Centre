﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Manager_WalletReport : Form
    {
        public Manager_WalletReport()
        {
            InitializeComponent();
        }

        private void Manager_WalletReport_Load(object sender, EventArgs e)
        {
            LoadWalletReport();
        }
        void LoadWalletReport()
        {
            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT 
                        WT.TransactionID,
                        U.FullName AS CustomerName,
                        WT.Amount,
                        WT.TransactionType,
                        WT.TransactionDate
                        FROM WalletTransactions WT
                        JOIN Users U ON WT.UserID = U.UserID";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();

                da.Fill(dt);

                dgvWalletReport.DataSource = dt;

                dgvWalletReport.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvWalletReport.ReadOnly = true;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ManagerDashboard admin = new ManagerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
