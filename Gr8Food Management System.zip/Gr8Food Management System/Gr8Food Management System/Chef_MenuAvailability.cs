﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Chef_MenuAvailability : Form
    {
        public Chef_MenuAvailability()
        {
            InitializeComponent();
        }


        private void Chef_MenuAvailability_Load(object sender, EventArgs e)
        {
            LoadMenu();
        }

        void LoadMenu()
        {
            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT m.MenuID,
                                m.MenuName,
                                m.Description,
                                m.Price,
                                c.CategoryName,
                                CASE 
                                    WHEN m.IsAvailable = 1 THEN 'Available'
                                    ELSE 'Not Available'
                                END AS Availability
                         FROM Menu m
                         JOIN Categories c ON m.CategoryID = c.CategoryID
                         WHERE m.ChefID=@chef";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@chef", Session.UserID);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvMenu.DataSource = dt;
                dgvMenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvMenu.ReadOnly = true;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtMenuID.Text == "" || cmbAvailability.SelectedIndex == -1)
            {
                MessageBox.Show("Please enter Menu ID and select availability");
                return;
            }

            int availability = (cmbAvailability.Text == "Available") ? 1 : 0;

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"UPDATE Menu
                         SET IsAvailable=@status
                         WHERE MenuID=@id AND ChefID=@chef";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@status", availability);
                cmd.Parameters.AddWithValue("@id", txtMenuID.Text);
                cmd.Parameters.AddWithValue("@chef", Session.UserID);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    MessageBox.Show("Availability Updated Successfully");
                    LoadMenu();
                }
                else
                {
                    MessageBox.Show("Menu not found");
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChefDashboard admin = new ChefDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
