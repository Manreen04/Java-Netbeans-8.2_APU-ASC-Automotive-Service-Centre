﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Customer_OrderStatus : Form
    {
        public Customer_OrderStatus()
        {
            InitializeComponent();
        }

        private void Customer_OrderStatus_Load(object sender, EventArgs e)
        {
            LoadOrders();
        }

        void LoadOrders()
        {
            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT OrderID,
                                OrderDate,
                                TotalAmount,
                                Status
                         FROM Orders
                         WHERE CustomerID = @cust";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@cust", Session.UserID);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvOrders.DataSource = dt;
                dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvOrders.ReadOnly = true;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtOrderID.Text == "")
            {
                MessageBox.Show("Please enter Order ID");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                int orderID = Convert.ToInt32(txtOrderID.Text);

                // 1️⃣ Get order amount and status
                SqlCommand cmd = new SqlCommand(
                    "SELECT TotalAmount, Status FROM Orders WHERE OrderID=@id AND CustomerID=@cust", con);

                cmd.Parameters.AddWithValue("@id", orderID);
                cmd.Parameters.AddWithValue("@cust", Session.UserID);

                SqlDataReader dr = cmd.ExecuteReader();

                if (!dr.Read())
                {
                    MessageBox.Show("Order not found");
                    dr.Close();
                    return;
                }

                decimal amount = Convert.ToDecimal(dr["TotalAmount"]);
                string status = dr["Status"].ToString();

                dr.Close();

                if (status == "Completed")
                {
                    MessageBox.Show("Completed orders cannot be cancelled");
                    return;
                }

                if (status == "Cancelled")
                {
                    MessageBox.Show("Order already cancelled");
                    return;
                }

                // 2️⃣ Update order status
                SqlCommand cancelCmd = new SqlCommand(
                    "UPDATE Orders SET Status='Cancelled' WHERE OrderID=@id", con);

                cancelCmd.Parameters.AddWithValue("@id", orderID);
                cancelCmd.ExecuteNonQuery();

                // 3️⃣ Refund wallet
                SqlCommand refundCmd = new SqlCommand(
                    "UPDATE Users SET WalletBalance = WalletBalance + @amount WHERE UserID=@uid", con);

                refundCmd.Parameters.AddWithValue("@amount", amount);
                refundCmd.Parameters.AddWithValue("@uid", Session.UserID);

                refundCmd.ExecuteNonQuery();

                MessageBox.Show("Order Cancelled and Amount Refunded");

                LoadOrders();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CustomerDashboard admin = new CustomerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
