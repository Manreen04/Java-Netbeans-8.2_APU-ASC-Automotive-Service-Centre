﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Customer_Feedback : Form
    {
        public Customer_Feedback()
        {
            InitializeComponent();
        }

        private void Customer_Feedback_Load(object sender, EventArgs e)
        {
            LoadCompletedOrders();
        }

        void LoadCompletedOrders()
        {
            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"SELECT OrderID, TotalAmount, Status
                         FROM Orders
                         WHERE CustomerID=@cust
                         AND Status='Completed'";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@cust", Session.UserID);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvOrders.DataSource = dt;
                dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtOrderID.Text == "" || txtMessage.Text == "")
            {
                MessageBox.Show("Please select an order and enter feedback");
                return;
            }

            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                @"INSERT INTO Feedback (OrderID, CustomerID, Message)
          VALUES (@oid, @cust, @msg)", con);

                cmd.Parameters.AddWithValue("@oid", txtOrderID.Text);
                cmd.Parameters.AddWithValue("@cust", Session.UserID);
                cmd.Parameters.AddWithValue("@msg", txtMessage.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Feedback Sent Successfully");

                txtOrderID.Clear();
                txtMessage.Clear();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CustomerDashboard admin = new CustomerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
