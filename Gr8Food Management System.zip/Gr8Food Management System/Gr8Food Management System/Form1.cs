﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = "SELECT UserID, Username, Role FROM Users WHERE Username=@username AND Password=@password";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    // Save session data
                    Session.UserID = Convert.ToInt32(reader["UserID"]);
                    Session.Username = reader["Username"].ToString();
                    Session.Role = reader["Role"].ToString();

                    MessageBox.Show("Login Successful!");

                    this.Hide();

                    // Redirect based on role
                    if (Session.Role == "Admin")
                    {
                        AdminDashboard admin = new AdminDashboard();
                        admin.Show();
                    }
                    else if (Session.Role == "Manager")
                    {
                        ManagerDashboard manager = new ManagerDashboard();
                        manager.Show();
                    }
                    else if (Session.Role == "Chef")
                    {
                        ChefDashboard chef = new ChefDashboard();
                        chef.Show();
                    }
                    else if (Session.Role == "Customer")
                    {
                        CustomerDashboard customer = new CustomerDashboard();
                        customer.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
