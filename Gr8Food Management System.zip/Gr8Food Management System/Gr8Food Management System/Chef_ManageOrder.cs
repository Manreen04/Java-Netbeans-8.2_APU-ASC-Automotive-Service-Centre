﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Chef_ManageOrder : Form
    {
        public Chef_ManageOrder()
        {
            InitializeComponent();
        }
        void LoadCategories()
        {
            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = "SELECT CategoryID, CategoryName FROM Categories";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cmbCategory.DataSource = dt;
                cmbCategory.DisplayMember = "CategoryName";  // what user sees
                cmbCategory.ValueMember = "CategoryID";      // value used in database
                cmbCategory.SelectedIndex = -1;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Chef_ManageOrder_Load(object sender, EventArgs e)
        {
            LoadCategories();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtMenuName.Text == "" || txtDescription.Text == "" || txtPrice.Text == "" || cmbCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"INSERT INTO Menu (MenuName, Description, Price, CategoryID, ChefID, IsAvailable)
                         VALUES (@name,@desc,@price,@category,@chef,1)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", txtMenuName.Text);
                cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@category", cmbCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@chef", Session.UserID);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Menu Added Successfully");

                //LoadMenuItems(); // refresh grid
                ClearFields();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtMenuID.Text == "" || txtEMenuName.Text == "" || txtEDescription.Text == "" || txtEPrice.Text == "" || cmbCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"UPDATE Menu 
                         SET MenuName=@name,
                             Description=@desc,
                             Price=@price,
                             CategoryID=@category
                         WHERE MenuID=@id AND ChefID=@chef";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", txtMenuID.Text);
                cmd.Parameters.AddWithValue("@name", txtMenuName.Text);
                cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@category", cmbCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@chef", Session.UserID);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("Menu Updated Successfully");
                else
                    MessageBox.Show("Menu not found");

                //LoadMenuItems();
                ClearFields();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtMenuID.Text == "" || txtMenuName.Text == "" || txtDescription.Text == "" || txtPrice.Text == "" || cmbCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = @"UPDATE Menu 
                         SET MenuName=@name,
                             Description=@desc,
                             Price=@price,
                             CategoryID=@category
                         WHERE MenuID=@id AND ChefID=@chef";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", txtMenuID.Text);
                cmd.Parameters.AddWithValue("@name", txtMenuName.Text);
                cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@category", cmbCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@chef", Session.UserID);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("Menu Updated Successfully");
                else
                    MessageBox.Show("Menu not found");

                //LoadMenuItems();
                ClearFields();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ClearFields()
        {
            txtMenuID.Clear();
            txtMenuName.Clear();
            txtDescription.Clear();
            txtPrice.Clear();
            cmbCategory.SelectedIndex = -1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChefDashboard admin = new ChefDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
