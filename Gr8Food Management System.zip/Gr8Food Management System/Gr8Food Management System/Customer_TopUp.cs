﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Customer_TopUp : Form
    {
        public Customer_TopUp()
        {
            InitializeComponent();
        }

        private void Customer_TopUp_Load(object sender, EventArgs e)
        {
            LoadBalance();
        }

        void LoadBalance()
        {
            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                "SELECT Balance FROM Wallet WHERE UserID=@uid", con);

                cmd.Parameters.AddWithValue("@uid", Session.UserID);

                decimal balance = Convert.ToDecimal(cmd.ExecuteScalar());

                lblBalance.Text = "Balance: RM " + balance.ToString();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnTopUp_Click(object sender, EventArgs e)
        {
            if (txtAmount.Text == "")
            {
                MessageBox.Show("Please enter amount");
                return;
            }

            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                decimal amount = Convert.ToDecimal(txtAmount.Text);

                // 1️⃣ Update Wallet Balance
                SqlCommand updateWallet = new SqlCommand(
                @"UPDATE Wallet
          SET Balance = Balance + @amount
          WHERE UserID=@uid", con);

                updateWallet.Parameters.AddWithValue("@amount", amount);
                updateWallet.Parameters.AddWithValue("@uid", Session.UserID);

                updateWallet.ExecuteNonQuery();

                // 2️⃣ Insert Transaction
                SqlCommand insertTransaction = new SqlCommand(
                @"INSERT INTO WalletTransactions(UserID, Amount, TransactionType)
          VALUES(@uid, @amount, 'TopUp')", con);

                insertTransaction.Parameters.AddWithValue("@uid", Session.UserID);
                insertTransaction.Parameters.AddWithValue("@amount", amount);

                insertTransaction.ExecuteNonQuery();

                MessageBox.Show("Wallet Top-Up Successful");

                txtAmount.Clear();

                LoadBalance();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CustomerDashboard admin = new CustomerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
