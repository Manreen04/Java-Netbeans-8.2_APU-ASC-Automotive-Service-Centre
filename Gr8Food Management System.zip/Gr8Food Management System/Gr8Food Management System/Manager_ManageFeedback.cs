﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Manager_ManageFeedback : Form
    {
        public Manager_ManageFeedback()
        {
            InitializeComponent();
        }

        private void Manager_ManageFeedback_Load(object sender, EventArgs e)
        {
            LoadFeedback();
        }

        void LoadFeedback()
        {
            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = "SELECT FeedbackID, OrderID, CustomerID, Message, Response, FeedbackDate FROM Feedback";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();

                da.Fill(dt);

                dgvFeedback.DataSource = dt;

                dgvFeedback.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtFeedbackID.Text == "" || txtResponse.Text == "")
            {
                MessageBox.Show("Please enter Feedback ID and Response");
                return;
            }

            SqlConnection con = new SqlConnection(
            "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                string query = "UPDATE Feedback SET Response=@response WHERE FeedbackID=@id";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@response", txtResponse.Text);
                cmd.Parameters.AddWithValue("@id", txtFeedbackID.Text);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    MessageBox.Show("Response Added Successfully");

                    LoadFeedback(); // refresh table

                    txtFeedbackID.Clear();
                    txtResponse.Clear();
                }
                else
                {
                    MessageBox.Show("Feedback ID not found");
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ManagerDashboard admin = new ManagerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
