﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gr8Food_Management_System
{
    public partial class Customer_PlaceOrder : Form
    {
        public Customer_PlaceOrder()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtMenuID.Text == "" || txtQuantity.Text == "")
            {
                MessageBox.Show("Please enter Menu ID and Quantity");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                int menuID = Convert.ToInt32(txtMenuID.Text);
                int qty = Convert.ToInt32(txtQuantity.Text);

                // 1️⃣ Get menu price
                SqlCommand getPrice = new SqlCommand(
                    "SELECT Price FROM Menu WHERE MenuID=@id", con);

                getPrice.Parameters.AddWithValue("@id", menuID);

                decimal price = Convert.ToDecimal(getPrice.ExecuteScalar());

                decimal total = price * qty;

                // 2️⃣ Check wallet balance
                SqlCommand getBalance = new SqlCommand(
                    "SELECT WalletBalance FROM Users WHERE UserID=@uid", con);

                getBalance.Parameters.AddWithValue("@uid", Session.UserID);

                decimal balance = Convert.ToDecimal(getBalance.ExecuteScalar());

                if (balance < total)
                {
                    MessageBox.Show("Insufficient Wallet Balance");
                    return;
                }

                // 3️⃣ Insert into Orders
                SqlCommand orderCmd = new SqlCommand(
                @"INSERT INTO Orders(CustomerID, OrderDate, TotalAmount, Status)
          VALUES(@cust, GETDATE(), @total, 'Pending');
          SELECT SCOPE_IDENTITY();", con);

                orderCmd.Parameters.AddWithValue("@cust", Session.UserID);
                orderCmd.Parameters.AddWithValue("@total", total);

                int orderID = Convert.ToInt32(orderCmd.ExecuteScalar());

                // 4️⃣ Insert into OrderDetails
                SqlCommand detailCmd = new SqlCommand(
                @"INSERT INTO OrderDetails(OrderID, MenuID, Quantity)
          VALUES(@oid, @mid, @qty)", con);

                detailCmd.Parameters.AddWithValue("@oid", orderID);
                detailCmd.Parameters.AddWithValue("@mid", menuID);
                detailCmd.Parameters.AddWithValue("@qty", qty);

                detailCmd.ExecuteNonQuery();

                // 5️⃣ Deduct wallet balance
                SqlCommand updateWallet = new SqlCommand(
                @"UPDATE Users
          SET WalletBalance = WalletBalance - @amount
          WHERE UserID=@uid", con);

                updateWallet.Parameters.AddWithValue("@amount", total);
                updateWallet.Parameters.AddWithValue("@uid", Session.UserID);

                updateWallet.ExecuteNonQuery();

                MessageBox.Show("Order Placed Successfully");

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (txtMenuID.Text == "" || txtQuantity.Text == "")
            {
                MessageBox.Show("Please enter Menu ID and Quantity");
                return;
            }

            SqlConnection con = new SqlConnection(
                "Data Source=DESKTOP-4G3LAR7\\SQLEXPRESS;Initial Catalog=Gr8FoodDB;Integrated Security=True");

            try
            {
                con.Open();

                int menuID = Convert.ToInt32(txtMenuID.Text);
                int qty = Convert.ToInt32(txtQuantity.Text);

                // Get price of menu item
                SqlCommand cmd = new SqlCommand(
                    "SELECT Price FROM Menu WHERE MenuID=@id", con);

                cmd.Parameters.AddWithValue("@id", menuID);

                decimal price = Convert.ToDecimal(cmd.ExecuteScalar());

                decimal total = price * qty;

                txtTotal.Text = total.ToString();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CustomerDashboard admin = new CustomerDashboard();
            admin.Show();
            this.Hide();
        }
    }
}
